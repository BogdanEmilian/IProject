package com.example.iproject;

public interface Meds {
    public void setQuantity(int barcode, int quantity);
}
