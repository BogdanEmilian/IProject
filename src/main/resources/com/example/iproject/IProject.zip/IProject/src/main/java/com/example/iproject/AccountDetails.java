package com.example.iproject;

public interface AccountDetails {
    public void setRole(String name, String role);
}
